/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
    ListView,
} from 'react-native';
import { StackNavigator } from 'react-navigation';


class WatchFace extends Component {
    static propTypes = {
        totalTime: React.PropTypes.string.isRequired,
    };

    render() {
        return (
            <View style={styles.watchFace}>
                <Text style={styles.totalTime}>{this.props.totalTime}</Text>
            </View>
    );
    }
}

class WatchControl extends Component {
    static propTypes = {
        startWatch: React.PropTypes.func.isRequired,
        stopWatch: React.PropTypes.func.isRequired,
        isStart: React.PropTypes.bool.isRequired
    };

    constructor(props) {
        super(props);
        this.state = {
            startBtnText: '开始',
            endBtnText: '结束',
        }
    }

    startWatch() {
        if (this.props.isStart) {
            this.props.startWatch()
            this.setState({
                startBtnText: '继续',
            });
        }
        else {
            this.props.startWatch()
            this.setState({
                startBtnText: '暂停',
            });

        }
    }

    stopWatch() {
      this.props.stopWatch();

      this.setState({
          startBtnText: '开始',
      });
    }

    render() {
        return (
            <View style={styles.watchControl}>
                <View style={styles.leftControl}>
                <TouchableOpacity style={styles.btn} onPress={()=> this.stopWatch()}>
                    <Text style={styles.endText}>{this.state.endBtnText}</Text>
                </TouchableOpacity>
                </View>
                <View style={styles.rightControl}>
                <TouchableOpacity style={styles.btn} onPress={()=> this.startWatch()}>
                    <Text style={[styles.startText]}>{this.state.startBtnText}</Text>
                </TouchableOpacity>
                </View>
            </View>
        );
    }
}

export default class ZCJRNTimeDemoPage extends Component {
    static navigationOptions = {
        title: '计时器',
    };
    constructor() {
        super();
        this.state = {
            isStart: false,
            totalTime: "00:00:00",
            timeCount: 0
        };
        this.interval = null;
    }

    startWatch() {
        if (this.state.isStart) {
            this.setState( {
                isStart: false,
            })
            clearInterval(this.interval);
        }
        else {
            this.setState({
                isStart: true,
            })

            let hour, minute, second;
            this.interval = setInterval(
            () => {
                let timeCount = this.state.timeCount;
                hour = Math.floor(timeCount / 3600);
                minute = Math.floor((timeCount - (hour * 3600)) / 60);
                second = Math.floor(timeCount % 60);
                this.setState({
                    timeCount: timeCount + 1,
                    totalTime: (hour<10? "0"+hour:hour)+":"+(minute<10? "0"+minute:minute)+":"+(second<10? "0"+second:second),
                })
                
            }, 1000
        );
        }

    }

    stopWatch() {
        this.setState({
            timeCount: 0,
            totalTime: "00:00:00",
            isStart: false,
        })
        clearInterval(this.interval);
    }


    componentWillUnmount() {
      this.stopWatch();
    }

    render() {
        return (
            <View style={{backgroundColor: '#fff', alignItems: 'center'}}>
                <WatchFace totalTime={this.state.totalTime}/>
                <WatchControl isStart={this.state.isStart} startWatch={()=>this.startWatch()} stopWatch={()=>this.stopWatch()}/>
            </View>

        );
    }
}

const styles = StyleSheet.create({
    watchFace: {
        paddingTop: 40,
        paddingLeft: 30,
        paddingRight: 30,
        paddingBottom: 40,
        height: 170,
        width: 375,
        borderColor: '#ddd',
        borderBottomWidth: 1,
        backgroundColor: '#fff',
    },
    totalTime: {
        fontSize: 60,
        top: 30,
        textAlign: 'center',
    },

    watchControl: {
        width: 375,
        height: 100,
        flexDirection: 'row',
        backgroundColor: '#f3f3f3',
        paddingTop: 20, paddingLeft: 60, paddingRight:60, paddingBottom:10,
    },
    leftControl: {
        flex: 1,
        alignItems: 'flex-start'
    },
    rightControl: {
        flex: 1,
        alignItems: 'flex-end'
    },
    btn: {
        width: 70,
        height: 70,
        borderRadius: 35,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
    },
    startText: {
        fontSize: 14,
        backgroundColor: 'transparent',
        color: '#60B644'
    },
    endText: {
        fontSize: 14,
        backgroundColor: 'transparent',
        color: '#555'
    },

});


const ZCJRNTimeDemo = StackNavigator({
  Home: { screen: ZCJRNTimeDemoPage },
});

AppRegistry.registerComponent('ZCJRNTimeDemo', () => ZCJRNTimeDemo);
