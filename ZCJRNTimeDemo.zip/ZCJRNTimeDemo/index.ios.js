/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 * @flow
 */

import React, { Component } from 'react';
import {
    AppRegistry,
    StyleSheet,
    Text,
    View,
    TouchableOpacity,
} from 'react-native';
import { StackNavigator } from 'react-navigation';


class WatchFace extends Component {
    static propTypes = {
        totalTime: React.PropTypes.string.isRequired,
    };

    render() {
        return (
            <Text style={styles.totalTime}>
                {this.props.totalTime}
            </Text>
        );
    }
}

class WatchControl extends Component {
    static propTypes = {
        startWatch: React.PropTypes.func.isRequired,
        stopWatch: React.PropTypes.func.isRequired,
        isStart: React.PropTypes.bool.isRequired
    };

    constructor(props) {
        super(props);
        this.state = {
            startBtnText: '开始',
            endBtnText: '结束',
        }
    }

    startWatch() {
        if (this.props.isStart) {
            this.props.startWatch()
            this.setState({
                startBtnText: '继续',
            });
        }
        else {
            this.props.startWatch()
            this.setState({
                startBtnText: '暂停',
            });

        }
    }

    stopWatch() {
      this.props.stopWatch();

      this.setState({
          startBtnText: '开始',
      });
    }

    render() {
        return (
            <View style={styles.watchControl}>
                <TouchableOpacity style={styles.btn} onPress={()=> this.stopWatch()}>
                    <Text style={styles.endText}>
                        {this.state.endBtnText}
                    </Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.btn} onPress={()=> this.startWatch()}>
                    <Text style={styles.startText}>
                        {this.state.startBtnText}
                    </Text>
                </TouchableOpacity>
            </View>
        );
    }
}

export default class ZCJRNTimeDemoPage extends Component {
    static navigationOptions = {
        title: '计时器',
    };
    constructor() {
        super();
        this.state = {
            isStart: false,
            totalTime: "00:00:00",
            timeCount: 0
        };
        this.interval = null;
    }

    startWatch() {
        if (this.state.isStart) {
            this.setState( {
                isStart: false,
            })
            clearInterval(this.interval);
        }
        else {
            this.setState({
                isStart: true,
            })

            let hour, minute, second;
            this.interval = setInterval(
            () => {
                let timeCount = this.state.timeCount;
                hour = Math.floor(timeCount / 3600);
                minute = Math.floor((timeCount - (hour * 3600)) / 60);
                second = Math.floor(timeCount % 60);
                this.setState({
                    timeCount: timeCount + 1,
                    totalTime: (hour<10? "0"+hour:hour)+":"+(minute<10? "0"+minute:minute)+":"+(second<10? "0"+second:second),
                })
                
            }, 1000
        );
        }

    }

    stopWatch() {
        this.setState({
            timeCount: 0,
            totalTime: "00:00:00",
            isStart: false,
        })
        clearInterval(this.interval);
    }


    componentWillUnmount() {
      this.stopWatch();
    }

    render() {
        return (
            <View style={{backgroundColor: '#fff'}}>
                <WatchFace
                    totalTime={this.state.totalTime}
                />
                <WatchControl
                    isStart={this.state.isStart}
                    startWatch={()=>this.startWatch()}
                    stopWatch={()=>this.stopWatch()}
                />
            </View>

        );
    }
}

const styles = StyleSheet.create({
    totalTime: {
        fontSize: 60,
        textAlign: 'center',
        paddingTop: 70,
        paddingBottom: 30,
    },
    watchControl: {
        backgroundColor: '#f3f3f3',
        height: 100,
        paddingHorizontal: 60,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between'
    },
    btn: {
        backgroundColor: 'white',
        width: 70,
        height: 70,
        borderRadius: 35,
        alignItems: 'center',
        justifyContent: 'center',
    },
    startText: {
        fontSize: 14,
        color: '#60B644'
    },
    endText: {
        fontSize: 14,
        color: '#555'
    },

});


const ZCJRNTimeDemo = StackNavigator({
  Home: { screen: ZCJRNTimeDemoPage },
});

AppRegistry.registerComponent('ZCJRNTimeDemo', () => ZCJRNTimeDemo);
